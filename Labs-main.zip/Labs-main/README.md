# Labs
I am actively refining my understanding of GitHub, and this repository serves as a professional showcase of Python code, highlighting my technical proficiency for recruiters and industry networks.
These started from my local desktop.

10/27/2026 - created this repo when I was new to GitHub going to have to completely destroy this repo and rebuild
